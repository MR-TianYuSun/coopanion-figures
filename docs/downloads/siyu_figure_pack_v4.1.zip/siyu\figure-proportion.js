/**
 * 思语 · 桌宠形象包（比例锁定版 v2 · 备选方案）
 *
 * ★ 这是"锁二头身"方案。当前默认生效的是 figure.js（分件版）。
 *   想切换成这一版：把 figure.json 的 entry 改成 "./figure-proportion.js"。
 *   两版的 export 都是 createSiyuBody，不用改 export。
 *
 * 核心：比例不靠 AI 画准，靠代码锁定。
 * AI 只提供好看的贴图，头放哪、脚放哪、多大，全部由下面的参数决定。
 * 这就是官方大肥鱼的做法——它的 README 原文："x=128 在身体下方，鞋底 y=256"，
 * 位置是量出来的数字，不是生成模型画出来的。
 *
 * 用 viewBox 裁切：把同一张整图的"头部区域"和"身体区域"分别投到
 * logo space 的两个框里。AI 画成三头身也能被掰成二头身。
 *
 * 依赖资源：tex/full.png（整图去背景，1920×1920）。
 *
 * 已核实契约（Coopanion 源码）：
 * - 工厂 factory(base, { model, scheme, kit, loadImage, asset, host })
 * - petG 是 SVG <g>，logo space 256×256，脚底 y=256，朝右；kit 每帧写 transform
 * - draw(petG, face, frame) 每帧调用（静止也调），只写变化的属性
 */

const SVGNS = 'http://www.w3.org/2000/svg';

/**
 * ============ 唯一需要你改的地方 ============
 * 换图后，量 5 个数填进来。量法见《比例锁定_操作说明.md》。
 * 下面这组是 1920×1920 即梦图的 measure_figure.py 实测值：
 * 头顶 68、下巴 659、鞋底 1860、左右 563~1233。
 */
const IMAGE = {
  w: 1920,
  h: 1920,
  head: { x: 563, y: 68, w: 670, h: 591 },
  body: { x: 563, y: 659, w: 670, h: 1201 },
};

/**
 * 比例控制台：logo space 里头和身体各占多大、放哪。
 * 二头身 = 头高 128 + 身体高 128 = 256，脚底正好落在 y=256。
 * 想调胖瘦/高矮，改这里，不用动下面的逻辑。
 */
const PROPORTION = {
  stand: {
    head: { cx: 128, top: 0, w: 128, h: 128 },
    body: { cx: 128, top: 128, w: 116, h: 128 },
  },
  sit: {
    head: { cx: 128, top: 16, w: 124, h: 124 },
    body: { cx: 128, top: 140, w: 132, h: 116 },
  },
};

export async function createSiyuBody(base, { kit, asset, host }) {
  const el = (tag, attrs) => {
    const node = document.createElementNS(SVGNS, tag);
    for (const k in attrs) node.setAttribute(k, String(attrs[k]));
    return node;
  };

  const parts = {};
  let bodyRoot = null;

  function build(petG) {
    if (bodyRoot) return;
    bodyRoot = el('g', { class: 'siyu-body' });

    // 每一块 = 一个视口 svg（外层 x/y/w/h 决定放在哪、多大）
    //          + viewBox（决定取原图的哪一块）
    // 头、身体各自独立，所以比例由外层的数字说了算，与 AI 画的比例无关。
    for (const key of ['body', 'head']) {
      const img = el('image', {
        href: String(asset('tex/full.png')),
        x: 0, y: 0, width: IMAGE.w, height: IMAGE.h,
        preserveAspectRatio: 'none',
      });
      const viewport = el('svg', {
        preserveAspectRatio: 'none',
        viewBox: `${IMAGE[key].x} ${IMAGE[key].y} ${IMAGE[key].w} ${IMAGE[key].h}`,
      });
      viewport.appendChild(img);
      parts[key] = viewport;
      bodyRoot.appendChild(viewport);
    }

    petG.appendChild(bodyRoot);
    applyProportion(false);
  }

  /** 把头/身两块按 PROPORTION 摆进 256 方格——比例锁定的核心 */
  function applyProportion(sitting) {
    const p = sitting ? PROPORTION.sit : PROPORTION.stand;
    for (const key of ['head', 'body']) {
      const box = p[key];
      const node = parts[key];
      node.setAttribute('x', box.cx - box.w / 2);
      node.setAttribute('y', box.top);
      node.setAttribute('width', box.w);
      node.setAttribute('height', box.h);
    }
  }

  const last = { sit: null, rot: null };

  const figure = {
    extent: [62, 0, 194, 256],
    hits: [[128, 90, 58]],
    anchors: {
      look: [128, 82],
      tears: [[106, 100], [150, 100]],
      z: [168, 32],
      heart: [158, 38],
      bubble: [128, 12],
    },
    colors: { z: '#7C6BA8' },

    draw(petG, face, frame) {
      build(petG);

      // 坐姿：重新按坐姿比例摆放（脚底仍 256）
      const sitting = (frame.sit ?? 0) > 0.5;
      if (sitting !== last.sit) {
        applyProportion(sitting);
        last.sit = sitting;
      }

      // 走/跑：整组轻微摆动 + 上下颠
      const moving = frame.mode === 'walk' || frame.mode === 'run';
      const amp = frame.mode === 'run' ? 10 : 5;
      const rot = moving ? Math.round(Math.sin(frame.t * (frame.mode === 'run' ? 12 : 8)) * amp) : 0;
      if (rot !== last.rot) {
        bodyRoot.setAttribute('transform', `rotate(${rot} 128 256)`);
        last.rot = rot;
      }

      // 说话：轻微上下浮（不与走路叠加）
      if (!moving) {
        const dy = frame.talk > 0.02 ? Math.round(Math.sin(frame.t * 18) * 1.2) : 0;
        bodyRoot.setAttribute('transform', `translate(0 ${dy})`);
      }
    },

    dispose() {},
  };

  return kit.createBody(host, { figure });
}
