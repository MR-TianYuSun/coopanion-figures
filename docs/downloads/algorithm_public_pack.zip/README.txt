Coopanion 提示词算法体系 · 技术公开包
========================================
algorithm.md  算法总文档：问题诊断 → v3 设计 → 验证清单
mindmap.md    全景思维导图 8 分支 107 节点（含 11-26 可靠性加固）

配套在线版：https://mr-tianyusun.github.io/coopanion-figures/algorithm.html
本包已脱敏：无真名、无知识库 ID、无本机路径、无第三方个人信息。
